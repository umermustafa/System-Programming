package com.packages.Coffee;

public class Stage1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Starting to make a coffee");
		System.out.println("Grinding coffee beans");
		System.out.println("Boiling water");
		System.out.println("Mixing boiled water ");
		System.out.println("Pouring coffee into the cup");
		System.out.println("Pouring some milk into the cup");
		System.out.println("Coffee is ready");
	}

}
